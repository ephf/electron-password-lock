# Electron Password Lock

encrypt your files with a password lock